# CNEX:

A Modern Downloader Manager.

## Support CNEX:
### Crypto:
- Bitcoin Address:
  - bc1qlcyg5jdg43t222ww3fh6yq2nr04ky8g5455u3p
- ETH & USDT Address:
  - 0x505E3E9B2cb7023e4782059B3d46Bf3102d40a8D
 
### Buymeacoffee:
- [Buy me a coffee](https://buymeacoffee.com/notfaad)
  
