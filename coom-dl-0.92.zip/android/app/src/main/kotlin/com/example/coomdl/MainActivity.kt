package com.example.coomdl

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
