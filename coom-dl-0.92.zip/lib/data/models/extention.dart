import 'package:isar/isar.dart';
part "extention.g.dart";

@collection
class Extention {

  /// 
  /// 
  Id id = Isar.autoIncrement;
  late String Author;
  late String name;
  late String regexIden;
  late String entry;
}
